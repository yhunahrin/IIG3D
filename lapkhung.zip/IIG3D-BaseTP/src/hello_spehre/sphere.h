#ifndef SPHERE_H
#define SPHERE_H
#include "opengl_stuff.h"

// Defines several possible options for Sphere movement. Used as abstraction to stay away from window-system specific input methods
enum Sphere_Movement {
    LEFT1 = 0,
    FORWARD1,
    RIGHT1,
    BACKWARD1
};


/*------------------------------------------------------------------------------------------------------------------------*/
/*                                                Abstract Sphere                                                         */
/*------------------------------------------------------------------------------------------------------------------------*/

class Sphere {

public:
    Sphere(glm::vec3 position = glm::vec3(0.f, 0.f, 1.f), glm::vec3 up = glm::vec3(0.f, 1.f, 0.f), glm::vec3 look = glm::vec3(0.f, 0.f, 0.f), float zoom=45.f);
    virtual ~Sphere();

    // Returns the view matrix calculated using Eular Angles and the LookAt Matrix
    glm::mat4 viewmatrix() const;
    float &zoom();
    glm::vec3 &position();

    void setviewport(glm::vec4 viewport);

    // Processes input received from any keyboard-like input system. Accepts input parameter in the form of Sphere defined ENUM (to abstract it from windowing systems)
    virtual void processkeyboard(Sphere_Movement direction, GLfloat deltaTime);
    // Processes input received from a mouse input system.
    virtual void processmouseclick(int button, GLfloat xpos, GLfloat ypos);
    // Processes input received from a mouse input system. Expects the offset value in both the x and y direction.
    virtual void processmousemovement(int button, GLfloat xpos, GLfloat ypos, GLboolean constraint = true);
    // Processes input received from a mouse scroll-wheel event. Only requires input on the vertical wheel-axis
    virtual void processmousescroll(GLfloat yoffset);

protected:
    glm::vec3 _position;
    glm::vec3 _front;
    glm::vec3 _up;
    float _zoom;

    glm::vec4 _viewport;

    // mouse movement
    int _mousebutton;
    GLfloat _mousestartx;
    GLfloat _mousestarty;

};


/*------------------------------------------------------------------------------------------------------------------------*/
/*                                       Euler Sphere : Yaw, Pitch, Roll                                                  */
/*------------------------------------------------------------------------------------------------------------------------*/

// from learnopenGL tutorial
// Default Sphere values
constexpr GLfloat YAW1        = -90.0f;
constexpr GLfloat PITCH1      =  0.0f;
constexpr GLfloat SPEED1      =  3.0f;
constexpr GLfloat SENSITIVTY1 =  0.25f;
constexpr GLfloat ZOOM1       =  45.0f;

// An abstract Sphere class that processes input and calculates the corresponding Eular Angles, Vectors and Matrices for use in OpenGL
class EulerSphere : public Sphere {

public:

    // Constructor with vectors (default constructor)
    EulerSphere(glm::vec3 position = glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3 up = glm::vec3(0.0f, 1.0f, 0.0f), GLfloat yaw = YAW1, GLfloat pitch = PITCH1);

    ~EulerSphere();

    // Processes input received from any keyboard-like input system. Accepts input parameter in the form of Sphere defined ENUM (to abstract it from windowing systems)
    void processkeyboard(Sphere_Movement direction, GLfloat deltaTime) override;

    // Processes input received from a mouse input system. Expects the offset value in both the x and y direction.
    void processmousemovement(int button, GLfloat xpos, GLfloat ypos, GLboolean constrainPitch = true) override;

    // Processes input received from a mouse scroll-wheel event. Only requires input on the vertical wheel-axis
    void processmousescroll(GLfloat yoffset) override;

private:
    // Calculates the front vector from the Sphere's (updated) Eular Angles
    void updateSpherevectors();

    // Sphere Attributes
    glm::vec3 _right;
    glm::vec3 _worldup;
    // Eular Angles
    GLfloat _yaw;
    GLfloat _pitch;
    // Sphere options
    GLfloat _movementspeed;
    GLfloat _mousesensitivity;

};

/*------------------------------------------------------------------------------------------------------------------------*/
/*                                            Trackball Sphere                                                            */
/*------------------------------------------------------------------------------------------------------------------------*/

class TrackballSphere : public Sphere {
public:
    TrackballSphere(glm::vec3 position = glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3 up = glm::vec3(0.0f, 1.0f, 0.0f), glm::vec3 center = glm::vec3(0.0f, 0.0f, -1.0f));
    ~TrackballSphere();

    // Processes input received from any keyboard-like input system. Accepts input parameter in the form of Sphere defined ENUM (to abstract it from windowing systems)
    void processkeyboard(Sphere_Movement direction, GLfloat deltaTime) override;

    // Processes input received from a mouse input system.
    void processmouseclick(int button, GLfloat xpos, GLfloat ypos) override;

    // Processes input received from a mouse input system. Expects the offset value in both the x and y direction.
    void processmousemovement(int button, GLfloat xpos, GLfloat ypos, GLboolean constrainPitch = true) override;

    // Processes input received from a mouse scroll-wheel event. Only requires input on the vertical wheel-axis
    void processmousescroll(GLfloat yoffset) override;

private:
    // Distance to center
    float _radius;

    // Sphere options
    GLfloat _movementspeed;
    GLfloat _mousesensitivity;

    // rotation data
    glm::vec3 _rotstart;
    glm::vec3 _rotend;
    //pan data
    glm::vec2 _panstart;
    glm::vec2 _panend;

    glm::vec3 getmouseprojectiononball(float xpos, float ypos);
    glm::vec2 getmouseonscreen(float xpos, float ypos);
    void rotateSphere();
    void panSphere();
};

#endif // SPHERE_H
