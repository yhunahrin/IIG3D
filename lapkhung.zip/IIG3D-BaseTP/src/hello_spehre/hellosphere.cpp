#include "hellosphere.h"
#include <iostream>


/*------------------------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------------------------*/


#define deg2rad(x) float(M_PI)*(x)/180.f


static const char* vertexshader_source ="#version 330 core\n\
        layout (location = 0) in vec3 position;\n\
        layout (location = 1) in vec3 inormal;\n\
        uniform mat4 model;\n\
        uniform mat4 view;\n\
        uniform mat4 projection;\n\
        out vec3 fragpos;\n\
        out vec3 normal;\n\
        void main()\n\
        {\n\
            // Note that we read the multiplication from right to left\n\
            gl_Position = projection * view * model * vec4(position, 1.0f);\n\
            fragpos = vec3(model * vec4(position, 1.0));\n\
            normal = mat3(transpose(inverse(model)))*inormal;\n\
        }\n";

static const char* fragmentshader_source ="#version 330 core\n\
        in vec3 fragpos;\n\
        in vec3 normal;\n\
        out vec4 color;\n\
        void main()\n\
        {\n\
            //color = vec4(vec3(clamp(dot(normalize(normal), vec3(0,0,1)), 0, 1)), 1.0);\n\
            float ambientStrength = 0.1;\n\
            vec3 ambient = ambientStrength * vec3(1.2f, 1.0f, 2.0f);\n\
            //color = vec4(normalize(normal)*0.5+0.5, 1.0);\n\
            vec3 lightDir = normalize(vec3(1.2f, 1.0f, 2.0f) - fragpos);\n\
            float diff = max(dot(normalize(normal), lightDir), 0.0);\n\
            vec3 diffuse = diff * vec3(1,1,1);\n\
            vec3 result = (ambient + diffuse)*vec3(0.f, 1.f, 0.f);\n\
            color = vec4(result, 1.0);\n\
        }\n";


SimpleSphere::SimpleSphere(int width, int height) : OpenGLDemo(width, height), _activeSphere(0), _Sphere(nullptr) {
    // Initialise geometric data

    float const R = 1./(float)(rings+1);
    float const S = 1./(float)(sectors-1);
    int r, s;

    _vertices.resize(rings * sectors * 3);
    _normals.resize(rings * sectors * 3);
    _texcoodrs.resize(rings * sectors * 2);
    std::vector<GLfloat>::iterator v = _vertices.begin();
    std::vector<GLfloat>::iterator n = _normals.begin();
    std::vector<GLfloat>::iterator t = _texcoodrs.begin();

    for(r = 0; r < rings; r++) for(s = 0; s < sectors; s++) {

            /*if(r==0){
                float const y = sin(((1.-R)-0.5)*M_PI);
                float const x = cos(((1.-R)-0.5)*M_PI) * cos(2*M_PI);
                float const z = cos(((1.-R)-0.5)*M_PI) * sin(2*M_PI);

                *t = -1;
                *t = -1 ;

                *v = x*radius;
                *v = y*radius;
                *v = z*radius;

                *n = x;
                *n = y;
                *n = z;
             }
           */

            float const y = sin(((1.-(r+1)*R)-0.5)*M_PI);
            float const x = cos(((1.-(r+1)*R)-0.5)*M_PI) * cos(2*M_PI * s * S );
            float const z = cos(((1.-(r+1)*R)-0.5)*M_PI) * sin(2*M_PI * s * S );

            *t++ = s*S;
            *t++ = 1.-(r+1)*R ;

            *v++ = x * radius;
            *v++ = y * radius;
            *v++ = z * radius;

            *n++ = x;
            *n++ = y;
            *n++ = z;
           //if(r == rings-1)

    }
  _vertices.push_back(0.0);
  _vertices.push_back(radius);
  _vertices.push_back(0.0);
  _normals.push_back(0.0);
  _normals.push_back(1/radius);
  _normals.push_back(0.0);
  _vertices.push_back(0.0);
  _vertices.push_back(-radius);
  _vertices.push_back(0.0);


    _indices.resize((sectors*4)+rings * sectors * 6);
    std::vector<GLuint>::iterator i = _indices.begin();
    for(r = 0; r < rings-1; r++) {
        //if(r ==)

        *i++ = rings*sectors;
        *i++ = r;
        //*i++ = (r+1) * sectors + (s+1);
        *i++ = r+1;
        *i++ = rings*(sectors-1)+r;
        *i++ = (r+1)+rings*(sectors-1);
        *i++ = (rings*sectors+1);
    }
   for(r = 0; r < rings-1; r++) for(s = 0; s < sectors; s++) {

            *i++ = r * sectors + s;
            *i++ = r * sectors + (s+1);
//            //*i++ = (r+1) * sectors + (s+1);
            *i++ = (r+1) * sectors + (s);
//
             *i++ = r * sectors + (s+1);
              *i++ = (r+1) * sectors + (s);

//        //*i++ = (r+1) * sectors + (s+1);
             *i++ = (r+1) * sectors + (s+1);

    }



    // Initialize the geometry
    // 1. Generate geometry buffers
    glGenBuffers(1, &_vbo) ;
    glGenBuffers(1, &_nbo) ;
    glGenBuffers(1, &_ebo) ;
    glGenBuffers(1, &_tbo) ;
    glGenVertexArrays(1, &_vao) ;
    // 2. Bind Vertex Array Object
    glBindVertexArray(_vao);
        // 3. Copy our vertices array in a buffer for OpenGL to use
        glBindBuffer(GL_ARRAY_BUFFER, _vbo);
        glBufferData(GL_ARRAY_BUFFER, _vertices.size()*sizeof (GLfloat), _vertices.data(), GL_STATIC_DRAW);
        // 4. Then set our vertex attributes pointers
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
        glEnableVertexAttribArray(0);

        glBindBuffer(GL_ARRAY_BUFFER, _tbo);
        glBufferData(GL_ARRAY_BUFFER, _texcoodrs.size()*sizeof (GLfloat), _vertices.data(), GL_STATIC_DRAW);

        glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
        glEnableVertexAttribArray(0);

        // 5. Copy our normals array in a buffer for OpenGL to use
        glBindBuffer(GL_ARRAY_BUFFER, _nbo);
        glBufferData(GL_ARRAY_BUFFER, _normals.size()*sizeof (GLfloat), _normals.data(), GL_STATIC_DRAW);
        // 6. Copy our vertices array in a buffer for OpenGL to use
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
        glEnableVertexAttribArray(1);
        // 7. Copy our index array in a element buffer for OpenGL to use
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _ebo);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, _indices.size()*sizeof (GLint), _indices.data(), GL_STATIC_DRAW);
    //6. Unbind the VAO
        glBindVertexArray(0);

    // Initialize shaders
    GLint success;
    GLchar infoLog[512]; // warning fixed size ... request for LOG_LENGTH!!!
    GLuint vertexshader, fragmentshader;

    // 1. Generate the shader
    vertexshader = glCreateShader(GL_VERTEX_SHADER);
    // 2. set the source
    glShaderSource(vertexshader, 1, &vertexshader_source, NULL);
    // 3. Compile
    glCompileShader(vertexshader);
    // 4. test for compile error
    glGetShaderiv(vertexshader, GL_COMPILE_STATUS, &success);
    if(!success) {
        glGetShaderInfoLog(vertexshader, 512, NULL, infoLog);
        std::cerr << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;
    }

    fragmentshader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentshader, 1, &fragmentshader_source, NULL);
    glCompileShader(fragmentshader);
    glGetShaderiv(fragmentshader, GL_COMPILE_STATUS, &success);
    if(!success) {
        glGetShaderInfoLog(fragmentshader, 512, NULL, infoLog);
        std::cerr << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;
    }

    // 1. Generate the program
    _program = glCreateProgram();
    // 2. Attach the shaders to the program
    glAttachShader(_program, vertexshader);
    glAttachShader(_program, fragmentshader);
    // 3. Link the program
    glLinkProgram(_program);
    // 4. Test for link errors
    glGetProgramiv(_program, GL_LINK_STATUS, &success);
    if(!success) {
        glGetProgramInfoLog(_program, 512, NULL, infoLog);
        std::cerr << "ERROR::SHADER::LINK_FAILED\n" << infoLog << std::endl;
    }
    glDeleteShader(vertexshader);
    glDeleteShader(fragmentshader);

    _Sphereselector.push_back( []()->Sphere*{return new EulerSphere(glm::vec3(0.f, 0.f, 1.f));} );
    _Sphereselector.push_back( []()->Sphere*{return new TrackballSphere(glm::vec3(0.f, 0.f, 1.f),glm::vec3(0.f, 1.f, 0.f),glm::vec3(0.f, 0.f, 0.f));} );

    _Sphere.reset(_Sphereselector[_activeSphere]());

    _Sphere->setviewport(glm::vec4(0.f, 0.f, _width, _height));
    _view = _Sphere->viewmatrix();

    _projection = glm::perspective(_Sphere->zoom(), float(_width) / _height, 0.1f, 100.0f);
}

SimpleSphere::~SimpleSphere() {
    glDeleteProgram(_program);
    glDeleteBuffers(1, &_vbo);
    glDeleteBuffers(1, &_nbo);
    glDeleteBuffers(1, &_ebo);
    glDeleteBuffers(1, &_tbo);
    glDeleteVertexArrays(1, &_vao) ;
}

void SimpleSphere::resize(int width, int height){
    OpenGLDemo::resize(width, height);
    _Sphere->setviewport(glm::vec4(0.f, 0.f, _width, _height));
    _projection = glm::perspective(_Sphere->zoom(), float(_width) / _height, 0.1f, 100.0f);
}

void SimpleSphere::draw() {
    OpenGLDemo::draw();

    glUseProgram(_program);

    _view = _Sphere->viewmatrix();

    glUniformMatrix4fv( glGetUniformLocation(_program, "model"), 1, GL_FALSE, glm::value_ptr(_model));
    glUniformMatrix4fv( glGetUniformLocation(_program, "view"), 1, GL_FALSE, glm::value_ptr(_view));
    glUniformMatrix4fv( glGetUniformLocation(_program, "projection"), 1, GL_FALSE, glm::value_ptr(_projection));
    glBindVertexArray(_vao);
    glDrawElements(GL_TRIANGLES, _indices.size(), GL_UNSIGNED_INT, nullptr);
    glBindVertexArray(0);
}

void SimpleSphere::mouseclick(int button, float xpos, float ypos) {
    _button = button;
    _mousex = xpos;
    _mousey = ypos;
    _Sphere->processmouseclick(_button, xpos, ypos);
}

void SimpleSphere::mousemove(float xpos, float ypos) {
    _Sphere->processmousemovement(_button, xpos, ypos, true);
}

void SimpleSphere::keyboardmove(int key, double time) {
    _Sphere->processkeyboard(Sphere_Movement(key), time);
}

bool SimpleSphere::keyboard(unsigned char k) {
    switch(k) {
        case 'p':
            _activeSphere = (_activeSphere+1)%2;
            _Sphere.reset(_Sphereselector[_activeSphere]());
            _Sphere->setviewport(glm::vec4(0.f, 0.f, _width, _height));
            return true;
        default:
            return false;
    }
}
